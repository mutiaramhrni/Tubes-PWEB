const express = require('express')
const mysql = require('mysql2')
const expressLayouts = require('express-ejs-layouts')
const path = require('path')
const app = express()

//koneksi database
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    database: 'tb_pweb'
  });

  db.connect((err)=>{
    if(err) throw err
   console.log('Database terkoneksi!')
  //  const sql = "SELECT * FROM users";
  //     db.query(sql,(err,result)=>{
  //       console.log(result)
  //     })
   })

    app.set('views', path.join(__dirname, '/views'));
    //biar bisa pake css,img dan js
    app.use('/css', express.static(path.resolve(__dirname, "assets/css")));
    // app.use('/js', express.static(path.resolve(__dirname, "assets/js")));
    app.use('/img', express.static(path.resolve(__dirname, "assets/img")));

   //biar bisa pakai kodingan format ejs(yg % itu lohh)
   app.set('view engine', 'ejs')

   //biar bisa bikin layout
   app.use(expressLayouts);

   app.get('/', function (req, res) {
  res.render('index',{ 
    title:"HOME", 
    layout:"layouts/mylayout"
  }) 

})

  app.get('/profil', function (req, res) {
      res.render('profil',{ 
      title:"profil",
      layout:"layouts/mylayout"
      }) 
      const insertSql = "INSERT INTO users (username,email,password,active,avatar,created_at,updated_at) VALUES (?, ?, ?, ?, ?, now(), now())";

      db.query(insertSql,['nisa','nisa@gmail.com','141414','1','nisapng'],(err,rows,result)=>{
        let response = {
          message : "Data berhasil ditambahkan",
          lastId : rows.insertId,
          error : err
        }
        res.json(response);
      })
      

  })
  app.get('/upload', function (req, res) {
    res.render('upload',{ 
    title:"upload",
    layout:"layouts/mylayout"
    }) 
    res.send('')
  })

  app.get('/template', function (req, res) {
      res.render('template',{ 
      title:"template",
      layout:"layouts/mylayout"
      }) 
      res.send('')
  })
  app.get('/document', function (req, res) {
      res.render('document',{ 
      title:"document",
      layout:"layouts/mylayout"
      }) 
      res.send('')
  })

  app.get('/sign', function (req, res) {
    res.render('sign',{ 
    title:"sign",
    layout:"layouts/mylayout"
    }) 
    res.send('')
})

app.listen(3000,()=>{
    console.log("server sudah hidup")
  })