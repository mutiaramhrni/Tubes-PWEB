const fs = require('fs');
const express = require('express')
const mysql = require('mysql2')
const expressLayouts = require('express-ejs-layouts')
const path = require('path')
const moment = require('moment');
const multer = require('multer');
const bcrypt = require('bcrypt');
const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
const app = express()


//buat folder penampung file jika tidak ada
if (!fs.existsSync('./uploads')) {
  fs.mkdirSync('./uploads');
}

// Create multer storage configuration
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname);
  }
});

// Create multer upload configuration
const upload = multer({ storage: storage });

const saltRounds = 10;

// middleware untuk parsing request body
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(cookieParser());

    app.set('views',__dirname)
    app.set('views', path.join(__dirname, '/views'));
    //biar bisa pakai kodingan format ejs(yg % itu lohh)
    app.set('view engine', 'ejs')
    //biar bisa pake css,img dan js
    app.use('/css', express.static(path.resolve(__dirname, "assets/css")));
    // app.use('/js', express.static(path.resolve(__dirname, "assets/js")));
    app.use('/img', express.static(path.resolve(__dirname, "assets/img")));

   
   //biar bisa bikin layout
   app.use(expressLayouts);

//koneksi database
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    database: 'db_sign'
  });

  db.connect((err)=>{
    if(err) throw err
   console.log('Database terkoneksi!')
  //  const sql = "SELECT * FROM users";
  //     db.query(sql,(err,result)=>{
  //       console.log(result)
  //     })
   })

    app.get('/register', function (req, res) {
      res.render('register',{
        title : 'Register',
        layout : 'layouts/authLayout'
      });
  })

    app.get('/login', function (req, res) {
      res.render('login',{
        title : 'Login',
        layout : 'layouts/authLayout'
      });
  })

  app.post('/login', function (req, res) {
    const { username, password } = req.body;
  
    const sql = 'SELECT * FROM users WHERE username = ?';
  db.query(sql, [username], function(err, result) {
      if (err) throw err;
  
      if (result.length === 0) {
          res.status(401).send('Username atau password salah!');
          return;
      }
  
      const user = result[0];
  
      // compare password
      bcrypt.compare(password, user.password, function(err, isValid) {
          if (err) throw err;
  
          if (!isValid) {
              res.status(401).send('Username atau password salah!');
              return;
          }
  
          // generate token
          const token = jwt.sign({ user_id: user.user_id }, 'secret_key');
          res.cookie('token', token, { httpOnly: true });
  
          res.redirect('/');
      });
  });
  
  });

  //register
  app.post('/register', function (req, res) {
    const { email, username, password, confirm_password } = req.body;
    let account = [username, email]
    // check if username already exists
    const sqlCheck = 'SELECT * FROM users WHERE username = ? OR email = ?';
    db.query(sqlCheck, account, (err, result) => {
      if (err) throw err;
  
      if (result.length > 0) {
        // username already exists, send error response
        return res.status(400).send('Username atau email sudah terdaftar');
      }
  
      if (password !== confirm_password) {
        // Passwords do not match, send error response
        return res.status(400).send('Konfirmasi password tidak cocok!');
      }
  
      // hash password
      bcrypt.hash(password, saltRounds, function(err, hash) {
        if (err) throw err;
  
        // insert user to database
        const sqlInsert = 'INSERT INTO users (email, username, password) VALUES (?, ?, ?)';
        const values = [email, username, hash];
        db.query(sqlInsert, values, (err, result) => {
          if (err) throw err;
          console.log('user terdaftar');
          res.redirect('/login');
        });
      });
    });
  });

  function requireAuth(req, res, next) {
  
    const token = req.cookies.token;
  
    if (!token) {
      res.redirect('/login');
      return;
    }
    
  
    jwt.verify(token, 'secret_key', function(err, decoded) {
      if (err) {
        res.redirect('/login');
        return;
      }
  
      req.user_id = decoded.user_id;
      next();
    });
  }

  

    app.get('/', requireAuth,function (req, res) {
    let user_id = req.user_id;
  
    const selectUserSql = `SELECT * FROM users WHERE user_id = ${user_id}`;
    db.query(selectUserSql, (err, Result) => {
      if (err) throw err;
      res.render('index', {
        user: Result[0],
        title: 'Home',
        layout: 'layouts/mylayout'
      });
    }); 
  })

  //profil page
app.get('/profil', requireAuth, function (req, res) {
  let user_id = req.user_id;
  const selectSql = `SELECT * FROM users WHERE user_id = ${user_id}`;
  db.query(selectSql, (err,result)=>{
    if (err) throw err;
    // Periksa apakah user sudah login dan aktif
    if (result[0].active === 0) {
      res.render('profil',{
        user: result[0],
        title:'Profil',
        layout:'layouts/mylayout'
      })
    } else {
      // Jika user tidak aktif, arahkan kembali ke halaman login
      res.redirect('/login');
    }
  })
})

app.post('/edit-profil', upload.single('sign_img'), requireAuth, (req, res) => {
  let user_id = req.user_id;
  const { username, email } = req.body;
  const signImg = req.file.filename;

  // Insert data to MySQL
  const updateUserSql = 'UPDATE users SET username=?, email=?, sign_img=? WHERE user_id=?';
  const values = [username, email, signImg, user_id];
  db.query(updateUserSql, values, (err, result) => {
    if (err) {
      throw err;
    }
    console.log('Data inserted to MySQL!');

    // Copy file to img directory
    const source = path.join(__dirname, 'uploads', signImg);
    const destination = path.join(__dirname, 'assets', 'img', signImg);
    fs.copyFileSync(source, destination);

    res.redirect('/profil');
  });
});

app.get('/upload', requireAuth, function (req, res) {
  let user_id = req.user_id;
  
  const selectUserSql = `SELECT * FROM users WHERE user_id = ${user_id}`;
  db.query(selectUserSql, (err, Result) => {
    if (err) throw err;
    res.render('upload', {
      user: Result[0],
      title: 'upload',
      layout: 'layouts/mylayout'
    });
  });
});
  
  app.get('/document', requireAuth,function (req, res) {
    let user_id = req.user_id;
  
    const selectUserSql = `SELECT * FROM users WHERE user_id = ${user_id}`;
    db.query(selectUserSql, (err, Result) => {
      if (err) throw err;
      res.render('document', {
        user: Result[0],
        title: 'document',
        layout: 'layouts/mylayout'
      });
    });
  })

  app.get('/sign', requireAuth,function (req, res) {
    let user_id = req.user_id;
  
  const selectUserSql = `SELECT * FROM users WHERE user_id = ${user_id}`;
  db.query(selectUserSql, (err, Result) => {
    if (err) throw err;
    res.render('sign', {
      user: Result[0],
      title: 'sign',
      layout: 'layouts/mylayout'
    });
  });
})

app.listen(3000,()=>{
    console.log("server sudah hidup")
  })